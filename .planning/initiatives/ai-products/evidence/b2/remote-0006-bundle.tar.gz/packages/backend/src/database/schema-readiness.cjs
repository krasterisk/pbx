'use strict';

const { resolveDatabaseConfig } = require('./database-config.cjs');
const { loadMigrations, runMigrations } = require('../../database/migration-runner.cjs');

function assertReady(status, migrations, dialect) {
  const expected = migrations.at(-1)?.id;
  if (!expected || status.engine !== dialect) throw new Error('Database schema readiness: engine mismatch');
  if (status.historyState !== 'versioned') {
    throw new Error('Database schema readiness: unversioned schema; review the existing database and run db:migrate before startup');
  }
  if (status.dirty) throw new Error('Database schema readiness: interrupted migration; inspect db:migrate:status and repair before startup');
  if (status.schemaVersion !== expected || status.pending.length) {
    throw new Error(`Database schema readiness: expected ${expected}; run db:migrate before startup`);
  }
  return { engine: dialect, schemaVersion: expected };
}

async function checkSchemaReadiness(input = process.env) {
  const config = resolveDatabaseConfig(input);
  const migrations = loadMigrations(config.dialect);
  const status = await runMigrations({ config, migrations, mode: 'status' });
  return assertReady(status, migrations, config.dialect);
}

module.exports = { assertReady, checkSchemaReadiness };
