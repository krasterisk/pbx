/**
 * Phase 14-05 route_templates table + 3 built-in seeds (D-33).
 * Delegates to the module setup script — this repo has no migration runner
 * under src/database/; live apply is:
 *   npx ts-node -r tsconfig-paths/register src/modules/route-templates/setup-route-templates-schema.ts
 */
export {
  ROUTE_TEMPLATE_SCHEMA_STATEMENTS,
  builtInSeedStatements,
  setupRouteTemplatesSchema,
} from '../../modules/route-templates/setup-route-templates-schema';
